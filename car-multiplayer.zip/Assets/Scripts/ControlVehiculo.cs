﻿using UnityEngine;
using Fusion;

public struct DatosEntrada : INetworkInput
{
    public float Aceleracion;
    public float Direccion;
}

public class ControlVehiculo : NetworkBehaviour
{
    public float velocidad = 10f;
    public float rotacion = 100f;
    private Rigidbody rb;

    public override void Spawned()
    {
        rb = GetComponent<Rigidbody>();
        Debug.Log($"[ControlVehiculo] Spawned. InputAuthority: {Object.InputAuthority}, HasInputAuthority: {HasInputAuthority}");

        var renderer = GetComponent<Renderer>();
        if (renderer != null)
            renderer.material.color = HasInputAuthority ? Color.green : Color.gray;

        if (HasInputAuthority && Camera.main != null)
        {
            Camera.main.transform.SetParent(transform);
            Camera.main.transform.localPosition = new Vector3(0, 5, -8);
            Camera.main.transform.localRotation = Quaternion.Euler(20, 0, 0);
        }
    }

    public override void FixedUpdateNetwork()
    {
        if (!HasInputAuthority) return;
        if (GetInput<DatosEntrada>(out var input))
        {
            transform.position += transform.forward * input.Aceleracion * velocidad * Runner.DeltaTime;
            transform.Rotate(0f, input.Direccion * rotacion * Runner.DeltaTime, 0f);
        }
    }
}
